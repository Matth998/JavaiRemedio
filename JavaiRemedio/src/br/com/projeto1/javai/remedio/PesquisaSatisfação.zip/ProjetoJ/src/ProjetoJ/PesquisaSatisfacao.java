package ProjetoJ;

import java.util.Scanner;

public class PesquisaSatisfacao {

	public static void main(String[] args) {

		Scanner leia = new Scanner(System.in);
		int entrada =0 ;
		
		System.out.println("Escreva aqui a Nota desse projeto: ");
			entrada=leia.nextInt();
		
		if(entrada ==1) {
			System.out.println("Precisamos e vamos melhorar... \nMuito obrigado pelo seu feedback!");
			}
				else if(entrada ==2) {
					System.out.println("Precisamos melhorar ainda mais... \nMuito obrigado pelo seu feedback!");	
					}
				else if(entrada ==3) {
					System.out.println("Estamos crescendo e evoluindo com a sua ajuda...\nMuito obrigado pelo seu feedback!");
					}
				else if(entrada ==4) {
					System.out.println("� uma boa nota, mas vamos melhorar ainda mais...\nMuito obrigado pelo seu feedback!");
					}
				else if(entrada ==5) {
					System.out.println("Muito obrigado pelo seu feedback!\nVoc� � a causa do nosso crescimento! ");
					}
				else {
					System.out.println("Voc� digitou um n�mero inv�lido... vamos tentar de novo?");
					}
			}
}
